#include <stdio.h>

int main(){
	int A;
	double B;
	scanf("%d %lf", &A, &B);
	printf("%d\n", A+B);
return 0;
}
