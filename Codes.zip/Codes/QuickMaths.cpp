#include <stdio.h>

int main(){
	int A;
	scanf("%d", &A);
	printf("%d plus %d is %d\nminus one is %d\n", A, A, A+A, (A+A)-1);
	return 0;
}
