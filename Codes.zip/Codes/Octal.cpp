#include<stdio.h>

int main(){
	int N;
	scanf("%d", &N);
	printf("%o\n", N);
	return 0;
}
