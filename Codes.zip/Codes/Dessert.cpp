#include <stdio.h>
#include <math.h>

int main(){
    int N;
    long long int X;
    scanf("%d", &N);
    X=pow(2,N)-1;
    printf("%lld\n", X);
}
