#include <stdio.h>

int main(){
	char A,B;
	scanf("%c %c", &A, &B);
	printf("%d\n", A*B);
	return 0;
}
