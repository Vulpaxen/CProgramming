#include <stdio.h>

int main(){
	char first[20], second[20], third[20];
	scanf("%s %s %s", &first, &second, &third);
	printf("%s %s %s\n", third, second, first);
	return 0;
}
