#include<stdio.h>

int main(){
	int N;
	scanf("%d", &N);
	printf("%x\n", N);
	return 0;
}
