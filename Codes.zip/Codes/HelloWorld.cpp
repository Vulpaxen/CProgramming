#include <stdio.h>

	int main(){
		float a=2.5;
		int b=1;
		char d='1';
		int c=a+b;
		printf("%d",c);
	return 0;
	}
